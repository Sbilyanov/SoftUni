﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _07.RawData
{
    public class Cargo
    {
      
        public int CargoWeight { get; set; }

        public string CargoType { get; set; }
    }
}
